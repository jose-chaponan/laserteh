<footer class="w_100 section_top_center">
    <section class="w_100 section_middle_center">
        <section>
            <nav>
                <ul>
                    <li> <a href="#">About Us</a> </li>
                    <li> <a href="#">Products</a> </li>
                    <li> <a href="#">Blog</a> </li>
                    <li> <a href="#">Become a Distributor</a> </li>
                    <li> <a href="#">Education</a> </li>
                    <li> <a href="#">Gallery</a> </li>
                    <li> <a href="#">Contact Us</a> </li>
                </ul>
            </nav>
            <aside>
                <a href="#"> <img src="images/facebook.svg" alt=""> </a>
                <a href="#"> <img src="images/instagram.svg" alt=""> </a>
                <a href="#"> <img src="images/twitter.svg" alt=""> </a>
                <a href="#"> <img src="images/youtube.svg" alt=""> </a>
                <a href="#"> <img src="images/pinterest.svg" alt=""> </a>
            </aside>
        </section>
        <section>
            <p>Unnique USA Showroom</p>
            <p>2820 NW 108 Avenue, Miami FL 33172</p>
            <p>1-305-499-9388</p>
            <a href="mailto:info@unnique.com">info@unnique.com</a>
        </section>
    </section>
    <div class="legal align_center w_80">
        © 2018 Unnique - The Premium Brand of Hair Treatments | Enhance Your Beauty| Unnique.com. All Rights Reserved
    </div>
</footer>
